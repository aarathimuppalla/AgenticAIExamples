import { useState, useEffect, useRef, useCallback } from "react";

// ─── Constants & Config ───
const SPECIALTIES = ["General Medicine", "Radiology", "Cardiology", "Dermatology", "Ophthalmology", "Neurology", "Orthopedics", "Pulmonology", "Gastroenterology", "Nephrology", "Endocrinology", "Oncology"];
const DIAGNOSIS_TYPES = ["Preliminary Screening", "Differential Diagnosis", "Risk Assessment", "Follow-up Evaluation", "Emergency Triage"];
const DATA_TYPES = ["X-Ray", "CT Scan", "MRI", "Ultrasound", "Skin Photo", "Eye Scan", "Pathology Slide", "ECG", "Blood Report", "Urine Report", "Other"];

const CHRONIC_CONDITIONS = [
  { id: "diabetes", label: "Diabetes (Type 1/2)", icon: "🩸" },
  { id: "hypertension", label: "Hypertension", icon: "❤️" },
  { id: "heart_disease", label: "Heart Disease", icon: "🫀" },
  { id: "kidney_disease", label: "Kidney Disease", icon: "🫘" },
  { id: "thyroid", label: "Thyroid Disorders", icon: "🦋" },
  { id: "asthma", label: "Asthma / COPD", icon: "🫁" },
  { id: "liver", label: "Liver Disease", icon: "🟤" },
  { id: "arthritis", label: "Arthritis", icon: "🦴" },
];

const WORKFLOW_NODES = [
  { id: 1, label: "Patient Input", icon: "📥", color: "#0EA5E9" },
  { id: 2, label: "Preprocessing", icon: "⚙️", color: "#8B5CF6" },
  { id: 3, label: "Image Analysis", icon: "🔬", color: "#EC4899" },
  { id: 4, label: "Feature Extraction", icon: "🧬", color: "#F59E0B" },
  { id: 5, label: "Symptom Analysis", icon: "🩺", color: "#10B981" },
  { id: 6, label: "Disease Prediction", icon: "🎯", color: "#EF4444" },
  { id: 7, label: "Differential Dx", icon: "📊", color: "#6366F1" },
  { id: 8, label: "Context Memory", icon: "🧠", color: "#14B8A6" },
  { id: 9, label: "Decision Engine", icon: "⚡", color: "#F97316" },
  { id: 10, label: "Treatment Plan", icon: "💊", color: "#06B6D4" },
  { id: 11, label: "LLM Reasoning", icon: "🤖", color: "#A855F7" },
  { id: 12, label: "Feedback Loop", icon: "🔁", color: "#84CC16" },
  { id: 13, label: "Output", icon: "📋", color: "#0EA5E9" },
];

// ─── API Integration ───
async function callGroqLLM(systemPrompt, userMessage) {
  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 4000,
        system: systemPrompt,
        messages: [{ role: "user", content: userMessage }],
      }),
    });
    const data = await response.json();
    return data.content?.map((b) => b.text || "").join("\n") || "No response received.";
  } catch (err) {
    return "Error connecting to AI service: " + err.message;
  }
}

// ─── System Prompts ───
const SYSTEM_PROMPTS = {
  imageDiagnosis: `You are MediAI, an advanced healthcare diagnosis intelligence agent built by Aigenthix. You are assisting a healthcare professional with medical image interpretation.

IMPORTANT DISCLAIMER: You are an AI assistant and NOT a licensed medical professional. All outputs are for informational and educational support only. Always recommend consulting a qualified healthcare provider for actual diagnosis and treatment.

When analyzing medical images, provide:
1. **Image Assessment** — Describe what type of image it appears to be and quality observations
2. **Findings** — Possible abnormalities or notable features (be specific about regions, density, symmetry, etc.)
3. **Differential Diagnosis** — List 3-5 possible conditions ranked by likelihood with confidence percentages
4. **Risk Score** — Overall risk assessment (Low/Moderate/High/Critical) with a numeric score 0-100
5. **Recommended Next Steps** — Additional tests, imaging, or specialist consultations
6. **Clinical Correlation** — How findings correlate with provided patient data
7. **Urgency Level** — Whether immediate attention is required

Format your response in clear sections with headers. Use medical terminology but also provide plain-language explanations.`,

  symptomDiagnosis: `You are MediAI, an advanced clinical diagnosis intelligence agent by Aigenthix. You help healthcare professionals with symptom-based differential diagnosis.

DISCLAIMER: AI assistant only — not a substitute for professional medical judgment.

Given patient symptoms, history, and vitals, provide:
1. **Clinical Assessment Summary** — Overview of the presenting complaint
2. **Symptom Analysis** — Categorization and severity assessment of each symptom
3. **Differential Diagnosis** — Top 5 possible conditions with probability percentages
4. **Risk Stratification** — Low/Moderate/High/Critical with numeric score
5. **Recommended Diagnostic Workup** — Labs, imaging, and tests to confirm/rule out
6. **Red Flags** — Any alarming symptoms requiring immediate attention
7. **Initial Management Suggestions** — Supportive care or empiric treatment considerations
8. **Specialist Referral Recommendations** — Which specialists to involve

Be thorough, evidence-based, and clinically structured.`,

  labReport: `You are MediAI Lab Report Analyst by Aigenthix. You interpret laboratory results for healthcare professionals.

DISCLAIMER: AI-assisted interpretation only — clinical correlation required.

Given lab values, provide:
1. **Abnormal Values Summary** — Flag all out-of-range results with reference ranges
2. **Pattern Recognition** — Identify lab patterns suggesting specific conditions
3. **Clinical Significance** — What each abnormality might indicate
4. **Differential Diagnosis** — Conditions consistent with the lab pattern
5. **Risk Markers** — Identify critical values or concerning trends
6. **Recommended Follow-up Tests** — Additional labs or diagnostics needed
7. **Clinical Correlation Notes** — How results fit with patient history

Present as a structured report with clear color-coded severity indicators.`,

  chronicDisease: `You are MediAI Chronic Disease Monitor by Aigenthix. You help healthcare professionals track and manage chronic conditions.

DISCLAIMER: AI monitoring support only — clinical oversight required.

Given patient chronic disease data, provide:
1. **Disease Status Assessment** — Current control/severity level
2. **Trend Analysis** — Direction of key metrics (improving/stable/worsening)
3. **Risk Alerts** — Any values or trends requiring immediate attention
4. **Complication Risk** — Assessment of disease-related complication risks
5. **Management Optimization** — Suggestions for improving disease control
6. **Lifestyle Recommendations** — Diet, exercise, monitoring frequency
7. **Medication Considerations** — When to consider adjustments (generalized)
8. **Follow-up Timeline** — Recommended next check-up intervals`,

  treatmentPlan: `You are MediAI Treatment Planning Support by Aigenthix. You assist healthcare professionals in developing treatment strategies.

DISCLAIMER: AI-generated treatment support only — must be validated by qualified clinician.

Given diagnosis and patient profile, provide:
1. **Treatment Pathway Overview** — Primary and alternative treatment approaches
2. **First-Line Interventions** — Standard-of-care recommendations
3. **Alternative Options** — Second-line or complementary approaches
4. **Specialist Referral Pathway** — Which specialists and in what order
5. **Monitoring Plan** — What to track and how often
6. **Expected Timeline** — Anticipated treatment duration and milestones
7. **Risk-Benefit Analysis** — Key considerations for each approach
8. **Patient Education Points** — Key information to communicate to patient
9. **Case Summary** — Concise clinical summary for documentation`,

  patientExplain: `You are MediAI Patient Communication Assistant by Aigenthix. You translate complex medical findings into patient-friendly language.

Given clinical findings, translate into:
1. **Simple Summary** — What was found, in everyday language (8th-grade reading level)
2. **What This Means** — Explanation of the condition in relatable terms
3. **What Happens Next** — Clear next steps the patient should expect
4. **Questions to Ask Your Doctor** — Helpful questions for the patient's next visit
5. **Lifestyle Tips** — Practical, actionable health advice
6. **When to Seek Help** — Clear warning signs to watch for
7. **Support Resources** — General categories of support available

Use warm, reassuring, non-alarming language. Avoid medical jargon. Use analogies when helpful. Support multilingual output if requested.`,
};

// ─── Utility Functions ───
function parseMarkdownSections(text) {
  if (!text) return [];
  const lines = text.split("\n");
  const sections = [];
  let current = null;
  for (const line of lines) {
    const headerMatch = line.match(/^#{1,3}\s+\**(.+?)\**\s*$/) || line.match(/^#{1,3}\s+(.+)$/);
    const boldMatch = line.match(/^\**\d+\.\s*(.+?)\**\s*[—–-]/) || line.match(/^\**(.+?)\**\s*[—–-]/);
    if (headerMatch) {
      if (current) sections.push(current);
      current = { title: headerMatch[1].replace(/\*/g, ""), content: [] };
    } else if (boldMatch && !current) {
      current = { title: boldMatch[1].replace(/\*/g, ""), content: [] };
    } else if (current) {
      current.content.push(line);
    } else {
      if (!sections.length && line.trim()) {
        current = { title: "Overview", content: [line] };
      }
    }
  }
  if (current) sections.push(current);
  return sections;
}

function extractRiskScore(text) {
  const match = text?.match(/(\d{1,3})(?:\s*\/\s*100|\s*%|\s*out of 100)/i);
  if (match) return parseInt(match[1]);
  if (/critical/i.test(text)) return 90;
  if (/high/i.test(text)) return 72;
  if (/moderate/i.test(text)) return 48;
  if (/low/i.test(text)) return 22;
  return 35;
}

function getRiskColor(score) {
  if (score >= 75) return "#DC2626";
  if (score >= 50) return "#F59E0B";
  if (score >= 25) return "#3B82F6";
  return "#10B981";
}

function getRiskLabel(score) {
  if (score >= 75) return "Critical";
  if (score >= 50) return "Moderate";
  if (score >= 25) return "Low";
  return "Minimal";
}

// ─── Styles ───
const styles = {
  app: {
    fontFamily: "'DM Sans', 'Segoe UI', sans-serif",
    background: "#F0F4F8",
    minHeight: "100vh",
    color: "#1E293B",
  },
  header: {
    background: "linear-gradient(135deg, #0F172A 0%, #1E3A5F 50%, #0F766E 100%)",
    padding: "0",
    position: "relative",
    overflow: "hidden",
  },
  headerInner: {
    padding: "20px 32px",
    position: "relative",
    zIndex: 2,
  },
  marquee: {
    background: "rgba(255,255,255,0.08)",
    backdropFilter: "blur(10px)",
    padding: "8px 0",
    overflow: "hidden",
    whiteSpace: "nowrap",
    fontSize: "12px",
    color: "rgba(255,255,255,0.7)",
    letterSpacing: "0.5px",
  },
  title: {
    fontSize: "28px",
    fontWeight: 800,
    color: "#fff",
    margin: 0,
    letterSpacing: "-0.5px",
  },
  subtitle: {
    fontSize: "13px",
    color: "rgba(255,255,255,0.6)",
    margin: "4px 0 0 0",
    fontWeight: 400,
  },
  badge: {
    display: "inline-block",
    background: "rgba(16,185,129,0.2)",
    border: "1px solid rgba(16,185,129,0.3)",
    color: "#34D399",
    padding: "3px 10px",
    borderRadius: "20px",
    fontSize: "11px",
    fontWeight: 600,
    marginLeft: "12px",
  },
  tabBar: {
    display: "flex",
    gap: "2px",
    padding: "0 24px",
    background: "#fff",
    borderBottom: "1px solid #E2E8F0",
    overflowX: "auto",
  },
  tab: (active) => ({
    padding: "14px 18px",
    fontSize: "13px",
    fontWeight: active ? 700 : 500,
    color: active ? "#0F766E" : "#64748B",
    background: active ? "rgba(15,118,110,0.06)" : "transparent",
    border: "none",
    borderBottom: active ? "3px solid #0F766E" : "3px solid transparent",
    cursor: "pointer",
    whiteSpace: "nowrap",
    transition: "all 0.2s",
  }),
  container: {
    maxWidth: "1400px",
    margin: "0 auto",
    padding: "24px",
  },
  card: {
    background: "#fff",
    borderRadius: "16px",
    padding: "24px",
    boxShadow: "0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04)",
    border: "1px solid #E2E8F0",
  },
  cardTitle: {
    fontSize: "16px",
    fontWeight: 700,
    marginBottom: "16px",
    color: "#0F172A",
    display: "flex",
    alignItems: "center",
    gap: "8px",
  },
  label: {
    fontSize: "13px",
    fontWeight: 600,
    color: "#475569",
    marginBottom: "6px",
    display: "block",
  },
  input: {
    width: "100%",
    padding: "10px 14px",
    border: "1.5px solid #CBD5E1",
    borderRadius: "10px",
    fontSize: "14px",
    outline: "none",
    transition: "border-color 0.2s",
    boxSizing: "border-box",
    background: "#F8FAFC",
  },
  textarea: {
    width: "100%",
    padding: "10px 14px",
    border: "1.5px solid #CBD5E1",
    borderRadius: "10px",
    fontSize: "14px",
    outline: "none",
    minHeight: "100px",
    resize: "vertical",
    boxSizing: "border-box",
    background: "#F8FAFC",
    fontFamily: "inherit",
  },
  select: {
    width: "100%",
    padding: "10px 14px",
    border: "1.5px solid #CBD5E1",
    borderRadius: "10px",
    fontSize: "14px",
    outline: "none",
    background: "#F8FAFC",
    boxSizing: "border-box",
    cursor: "pointer",
  },
  btnPrimary: {
    padding: "12px 28px",
    background: "linear-gradient(135deg, #0F766E, #0EA5E9)",
    color: "#fff",
    border: "none",
    borderRadius: "12px",
    fontSize: "14px",
    fontWeight: 700,
    cursor: "pointer",
    display: "inline-flex",
    alignItems: "center",
    gap: "8px",
    transition: "all 0.2s",
    boxShadow: "0 2px 8px rgba(15,118,110,0.3)",
  },
  btnSecondary: {
    padding: "10px 20px",
    background: "#F1F5F9",
    color: "#475569",
    border: "1.5px solid #CBD5E1",
    borderRadius: "10px",
    fontSize: "13px",
    fontWeight: 600,
    cursor: "pointer",
  },
  btnDanger: {
    padding: "10px 20px",
    background: "#FEF2F2",
    color: "#DC2626",
    border: "1.5px solid #FECACA",
    borderRadius: "10px",
    fontSize: "13px",
    fontWeight: 600,
    cursor: "pointer",
  },
  grid2: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: "16px",
  },
  grid3: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap: "16px",
  },
  uploadZone: {
    border: "2px dashed #CBD5E1",
    borderRadius: "14px",
    padding: "40px 20px",
    textAlign: "center",
    cursor: "pointer",
    background: "#F8FAFC",
    transition: "all 0.2s",
  },
  imagePreview: {
    maxWidth: "100%",
    maxHeight: "300px",
    borderRadius: "12px",
    objectFit: "contain",
    border: "1px solid #E2E8F0",
  },
  riskMeter: (score) => ({
    width: "120px",
    height: "120px",
    borderRadius: "50%",
    background: `conic-gradient(${getRiskColor(score)} ${score * 3.6}deg, #E2E8F0 0deg)`,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  }),
  riskInner: {
    width: "90px",
    height: "90px",
    borderRadius: "50%",
    background: "#fff",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  sectionBlock: {
    padding: "16px",
    background: "#F8FAFC",
    borderRadius: "12px",
    marginBottom: "12px",
    borderLeft: "4px solid #0F766E",
  },
  workflowNode: (active, color) => ({
    display: "flex",
    alignItems: "center",
    gap: "8px",
    padding: "8px 14px",
    borderRadius: "10px",
    background: active ? `${color}15` : "#F8FAFC",
    border: `1.5px solid ${active ? color : "#E2E8F0"}`,
    fontSize: "12px",
    fontWeight: 600,
    color: active ? color : "#94A3B8",
    transition: "all 0.3s",
    minWidth: "130px",
  }),
  spinner: {
    width: "20px",
    height: "20px",
    border: "3px solid #E2E8F0",
    borderTop: "3px solid #0F766E",
    borderRadius: "50%",
    animation: "spin 0.8s linear infinite",
  },
  disclaimer: {
    padding: "14px 18px",
    background: "#FFFBEB",
    border: "1px solid #FDE68A",
    borderRadius: "10px",
    fontSize: "12px",
    color: "#92400E",
    lineHeight: 1.5,
  },
  kpiCard: (color) => ({
    padding: "18px",
    background: `linear-gradient(135deg, ${color}08, ${color}15)`,
    borderRadius: "14px",
    border: `1px solid ${color}30`,
    textAlign: "center",
  }),
};

// ─── Sub-Components ───
function WorkflowTracker({ activeNode }) {
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", marginBottom: "20px" }}>
      {WORKFLOW_NODES.map((node) => (
        <div key={node.id} style={styles.workflowNode(activeNode >= node.id, node.color)}>
          <span>{node.icon}</span>
          <span style={{ fontSize: "11px" }}>{node.label}</span>
          {activeNode === node.id && (
            <div style={styles.spinner} />
          )}
          {activeNode > node.id && <span style={{ color: "#10B981" }}>✓</span>}
        </div>
      ))}
    </div>
  );
}

function RiskScoreWidget({ score }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
      <div style={styles.riskMeter(score)}>
        <div style={styles.riskInner}>
          <span style={{ fontSize: "28px", fontWeight: 800, color: getRiskColor(score) }}>{score}</span>
          <span style={{ fontSize: "10px", color: "#64748B", fontWeight: 600 }}>/ 100</span>
        </div>
      </div>
      <div>
        <div style={{ fontSize: "18px", fontWeight: 700, color: getRiskColor(score) }}>
          {getRiskLabel(score)} Risk
        </div>
        <div style={{ fontSize: "12px", color: "#64748B", marginTop: "4px" }}>
          AI-computed risk assessment
        </div>
      </div>
    </div>
  );
}

function ResultSection({ title, content, icon, color }) {
  return (
    <div style={{ ...styles.sectionBlock, borderLeftColor: color || "#0F766E" }}>
      <div style={{ fontSize: "14px", fontWeight: 700, marginBottom: "8px", color: color || "#0F766E" }}>
        {icon} {title}
      </div>
      <div style={{ fontSize: "13px", color: "#334155", lineHeight: 1.7, whiteSpace: "pre-wrap" }}>
        {content}
      </div>
    </div>
  );
}

function ImageUploader({ image, setImage, imagePreviewUrl, setImagePreviewUrl }) {
  const fileRef = useRef(null);
  const handleFile = (file) => {
    if (!file) return;
    setImage(file);
    const reader = new FileReader();
    reader.onload = (e) => setImagePreviewUrl(e.target.result);
    reader.readAsDataURL(file);
  };
  return (
    <div>
      <div
        style={styles.uploadZone}
        onClick={() => fileRef.current?.click()}
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => { e.preventDefault(); handleFile(e.dataTransfer.files[0]); }}
      >
        {imagePreviewUrl ? (
          <img src={imagePreviewUrl} alt="Medical" style={styles.imagePreview} />
        ) : (
          <>
            <div style={{ fontSize: "40px", marginBottom: "8px" }}>🏥</div>
            <div style={{ fontWeight: 600, color: "#475569" }}>Upload Medical Image</div>
            <div style={{ fontSize: "12px", color: "#94A3B8", marginTop: "4px" }}>
              X-Ray, CT, MRI, Ultrasound, Skin Photo, Pathology
            </div>
            <div style={{ fontSize: "11px", color: "#CBD5E1", marginTop: "8px" }}>
              Click or drag and drop
            </div>
          </>
        )}
      </div>
      <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={(e) => handleFile(e.target.files[0])} />
    </div>
  );
}

function PatientDataForm({ data, setData }) {
  const update = (key, val) => setData((prev) => ({ ...prev, [key]: val }));
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <div style={styles.grid2}>
        <div>
          <label style={styles.label}>Patient Name</label>
          <input style={styles.input} placeholder="Full name" value={data.name || ""} onChange={(e) => update("name", e.target.value)} />
        </div>
        <div style={styles.grid2}>
          <div>
            <label style={styles.label}>Age</label>
            <input style={styles.input} type="number" placeholder="Age" value={data.age || ""} onChange={(e) => update("age", e.target.value)} />
          </div>
          <div>
            <label style={styles.label}>Gender</label>
            <select style={styles.select} value={data.gender || ""} onChange={(e) => update("gender", e.target.value)}>
              <option value="">Select</option>
              <option>Male</option>
              <option>Female</option>
              <option>Other</option>
            </select>
          </div>
        </div>
      </div>
      <div style={styles.grid2}>
        <div>
          <label style={styles.label}>Blood Pressure</label>
          <input style={styles.input} placeholder="e.g. 120/80 mmHg" value={data.bp || ""} onChange={(e) => update("bp", e.target.value)} />
        </div>
        <div>
          <label style={styles.label}>Heart Rate</label>
          <input style={styles.input} placeholder="e.g. 72 bpm" value={data.hr || ""} onChange={(e) => update("hr", e.target.value)} />
        </div>
      </div>
      <div style={styles.grid2}>
        <div>
          <label style={styles.label}>Temperature</label>
          <input style={styles.input} placeholder="e.g. 98.6°F" value={data.temp || ""} onChange={(e) => update("temp", e.target.value)} />
        </div>
        <div>
          <label style={styles.label}>SpO2</label>
          <input style={styles.input} placeholder="e.g. 98%" value={data.spo2 || ""} onChange={(e) => update("spo2", e.target.value)} />
        </div>
      </div>
      <div>
        <label style={styles.label}>Medical History</label>
        <textarea style={styles.textarea} placeholder="Past medical conditions, surgeries, allergies, medications..." value={data.history || ""} onChange={(e) => update("history", e.target.value)} />
      </div>
      <div>
        <label style={styles.label}>Current Medications</label>
        <input style={styles.input} placeholder="List current medications" value={data.medications || ""} onChange={(e) => update("medications", e.target.value)} />
      </div>
    </div>
  );
}

// ─── Main App ───
export default function MediAI() {
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(false);
  const [activeNode, setActiveNode] = useState(0);
  const [result, setResult] = useState("");
  const [riskScore, setRiskScore] = useState(null);
  const [feedback, setFeedback] = useState("");
  const [marqueeOffset, setMarqueeOffset] = useState(0);

  // Form states
  const [image, setImage] = useState(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState("");
  const [patientData, setPatientData] = useState({});
  const [symptoms, setSymptoms] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [diagnosisType, setDiagnosisType] = useState("");
  const [dataType, setDataType] = useState("");
  const [labValues, setLabValues] = useState("");
  const [chronicConditions, setChronicConditions] = useState([]);
  const [chronicData, setChronicData] = useState("");
  const [treatmentNotes, setTreatmentNotes] = useState("");
  const [clinicalFindings, setClinicalFindings] = useState("");
  const [patientLanguage, setPatientLanguage] = useState("English");

  // Marquee animation
  useEffect(() => {
    const timer = setInterval(() => setMarqueeOffset((p) => p - 1), 30);
    return () => clearInterval(timer);
  }, []);

  const tabs = [
    { label: "🔬 Image Diagnosis", icon: "🔬" },
    { label: "🩺 Symptom Diagnosis", icon: "🩺" },
    { label: "🧪 Lab Reports", icon: "🧪" },
    { label: "❤️ Chronic Disease", icon: "❤️" },
    { label: "💊 Treatment Plan", icon: "💊" },
    { label: "📋 Clinical Summary", icon: "📋" },
    { label: "👤 Patient Explanation", icon: "👤" },
  ];

  const simulateWorkflow = async (targetNode) => {
    for (let i = 1; i <= targetNode; i++) {
      setActiveNode(i);
      await new Promise((r) => setTimeout(r, 400 + Math.random() * 300));
    }
  };

  const clearAll = () => {
    setResult(""); setRiskScore(null); setFeedback(""); setActiveNode(0);
    setImage(null); setImagePreviewUrl(""); setSymptoms(""); setLabValues("");
    setChronicData(""); setTreatmentNotes(""); setClinicalFindings("");
  };

  const buildPatientContext = () => {
    const d = patientData;
    let ctx = "";
    if (d.name) ctx += `Patient: ${d.name}\n`;
    if (d.age) ctx += `Age: ${d.age}\n`;
    if (d.gender) ctx += `Gender: ${d.gender}\n`;
    if (d.bp) ctx += `Blood Pressure: ${d.bp}\n`;
    if (d.hr) ctx += `Heart Rate: ${d.hr}\n`;
    if (d.temp) ctx += `Temperature: ${d.temp}\n`;
    if (d.spo2) ctx += `SpO2: ${d.spo2}\n`;
    if (d.history) ctx += `Medical History: ${d.history}\n`;
    if (d.medications) ctx += `Medications: ${d.medications}\n`;
    if (specialty) ctx += `Specialty: ${specialty}\n`;
    if (diagnosisType) ctx += `Diagnosis Type: ${diagnosisType}\n`;
    return ctx;
  };

  const analyzeImage = async () => {
    if (!image && !symptoms) { alert("Please upload an image or provide symptoms."); return; }
    setLoading(true); setResult(""); setRiskScore(null);
    await simulateWorkflow(13);
    const ctx = buildPatientContext();
    const prompt = `MEDICAL IMAGE ANALYSIS REQUEST\n\nImage Type: ${dataType || "Not specified"}\n${ctx}\nAdditional symptoms/notes: ${symptoms || "None provided"}\n\nPlease note: An image has been uploaded (${image?.name || "unknown"}). Since you cannot directly view the image, provide a comprehensive template-based analysis for a ${dataType || "general medical"} image, covering all possible findings, differential diagnoses, and recommendations. Structure the analysis as if reviewing the image with the clinical context provided.\n\nProvide risk score as a number out of 100.`;
    const res = await callGroqLLM(SYSTEM_PROMPTS.imageDiagnosis, prompt);
    setResult(res);
    setRiskScore(extractRiskScore(res));
    setActiveNode(13);
    setLoading(false);
  };

  const analyzeSymptoms = async () => {
    if (!symptoms) { alert("Please enter symptoms."); return; }
    setLoading(true); setResult(""); setRiskScore(null);
    await simulateWorkflow(13);
    const ctx = buildPatientContext();
    const prompt = `SYMPTOM-BASED DIAGNOSIS REQUEST\n\n${ctx}\nPresenting Symptoms: ${symptoms}\n\nPerform a thorough differential diagnosis analysis. Provide risk score as a number out of 100.`;
    const res = await callGroqLLM(SYSTEM_PROMPTS.symptomDiagnosis, prompt);
    setResult(res);
    setRiskScore(extractRiskScore(res));
    setActiveNode(13);
    setLoading(false);
  };

  const analyzeLab = async () => {
    if (!labValues) { alert("Please enter lab values."); return; }
    setLoading(true); setResult(""); setRiskScore(null);
    await simulateWorkflow(13);
    const ctx = buildPatientContext();
    const prompt = `LAB REPORT INTERPRETATION REQUEST\n\n${ctx}\nLab Values:\n${labValues}\n\nProvide comprehensive lab interpretation with risk markers and clinical significance. Include risk score out of 100.`;
    const res = await callGroqLLM(SYSTEM_PROMPTS.labReport, prompt);
    setResult(res);
    setRiskScore(extractRiskScore(res));
    setActiveNode(13);
    setLoading(false);
  };

  const analyzeChronic = async () => {
    if (!chronicConditions.length && !chronicData) { alert("Please select conditions or enter data."); return; }
    setLoading(true); setResult(""); setRiskScore(null);
    await simulateWorkflow(13);
    const ctx = buildPatientContext();
    const conditions = chronicConditions.map((c) => CHRONIC_CONDITIONS.find((cc) => cc.id === c)?.label).join(", ");
    const prompt = `CHRONIC DISEASE MONITORING REQUEST\n\n${ctx}\nChronic Conditions: ${conditions || "Not specified"}\nRecent Data/Values:\n${chronicData || "Not provided"}\n\nProvide comprehensive chronic disease status assessment with risk score out of 100.`;
    const res = await callGroqLLM(SYSTEM_PROMPTS.chronicDisease, prompt);
    setResult(res);
    setRiskScore(extractRiskScore(res));
    setActiveNode(13);
    setLoading(false);
  };

  const analyzeTreatment = async () => {
    if (!treatmentNotes && !result) { alert("Please provide diagnosis info or run a diagnosis first."); return; }
    setLoading(true); setResult(""); setRiskScore(null);
    await simulateWorkflow(13);
    const ctx = buildPatientContext();
    const prompt = `TREATMENT PLANNING REQUEST\n\n${ctx}\nDiagnosis/Clinical Notes:\n${treatmentNotes || result}\n\nGenerate comprehensive treatment planning support with risk-benefit analysis.`;
    const res = await callGroqLLM(SYSTEM_PROMPTS.treatmentPlan, prompt);
    setResult(res);
    setActiveNode(13);
    setLoading(false);
  };

  const generateSummary = async () => {
    if (!result) { alert("Please run an analysis first to generate a clinical summary."); return; }
    setLoading(true);
    await simulateWorkflow(13);
    const prompt = `Generate a concise, structured clinical summary document from these findings. Format as a medical case report:\n\n${buildPatientContext()}\nFindings:\n${result}`;
    const res = await callGroqLLM(SYSTEM_PROMPTS.treatmentPlan, prompt);
    setResult(res);
    setActiveNode(13);
    setLoading(false);
  };

  const generatePatientExplanation = async () => {
    const source = clinicalFindings || result;
    if (!source) { alert("Please provide findings or run an analysis first."); return; }
    setLoading(true); setResult("");
    await simulateWorkflow(13);
    const prompt = `Translate these clinical findings into a patient-friendly explanation in ${patientLanguage}:\n\n${source}`;
    const res = await callGroqLLM(SYSTEM_PROMPTS.patientExplain, prompt);
    setResult(res);
    setActiveNode(13);
    setLoading(false);
  };

  const refineResult = async () => {
    if (!result || !feedback) return;
    setLoading(true);
    const prompt = `Previous analysis:\n${result}\n\nDoctor's feedback for refinement:\n${feedback}\n\nPlease refine and improve the analysis based on this feedback. Maintain all sections but update with the corrections/additions.`;
    const res = await callGroqLLM(SYSTEM_PROMPTS[Object.keys(SYSTEM_PROMPTS)[activeTab]] || SYSTEM_PROMPTS.symptomDiagnosis, prompt);
    setResult(res);
    setRiskScore(extractRiskScore(res));
    setFeedback("");
    setLoading(false);
  };

  const marqueeText = "  ◆  MediAI: Healthcare Diagnosis Intelligence Agent  ◆  Powered by Aigenthix  ◆  AI-Assisted Diagnostic Support  ◆  Medical Image Analysis  ◆  Clinical Decision Intelligence  ◆  Next-Generation Healthcare AI  ◆  Real-Time Diagnosis Support  ◆  Treatment Planning Assistant  ◆  ";

  const sections = parseMarkdownSections(result);
  const sectionColors = ["#0F766E", "#0EA5E9", "#8B5CF6", "#EC4899", "#F59E0B", "#EF4444", "#6366F1", "#14B8A6", "#F97316"];

  return (
    <div style={styles.app}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap');
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        * { box-sizing: border-box; }
        input:focus, textarea:focus, select:focus { border-color: #0F766E !important; box-shadow: 0 0 0 3px rgba(15,118,110,0.1); }
        button:hover { opacity: 0.92; transform: translateY(-1px); }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 10px; }
      `}</style>

      {/* Header */}
      <header style={styles.header}>
        <div style={{
          position: "absolute", inset: 0, opacity: 0.05,
          backgroundImage: "radial-gradient(circle at 20% 80%, #0EA5E9 1px, transparent 1px), radial-gradient(circle at 80% 20%, #10B981 1px, transparent 1px)",
          backgroundSize: "30px 30px",
        }} />
        <div style={styles.marquee}>
          <div style={{ transform: `translateX(${marqueeOffset % 1200}px)`, display: "inline-block" }}>
            {marqueeText}{marqueeText}
          </div>
        </div>
        <div style={styles.headerInner}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <h1 style={styles.title}>
                🏥 MediAI
                <span style={styles.badge}>v2.0</span>
              </h1>
              <p style={styles.subtitle}>Healthcare Diagnosis Intelligence Agent by Aigenthix</p>
            </div>
            <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
              <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#34D399", boxShadow: "0 0 8px #34D399" }} />
              <span style={{ fontSize: "12px", color: "rgba(255,255,255,0.6)" }}>AI Engine Active</span>
            </div>
          </div>
        </div>
      </header>

      {/* Tab Bar */}
      <nav style={styles.tabBar}>
        {tabs.map((tab, i) => (
          <button key={i} style={styles.tab(activeTab === i)} onClick={() => { setActiveTab(i); setResult(""); setActiveNode(0); setRiskScore(null); }}>
            {tab.label}
          </button>
        ))}
      </nav>

      {/* Main Content */}
      <div style={styles.container}>
        {/* Disclaimer */}
        <div style={{ ...styles.disclaimer, marginBottom: "20px" }}>
          ⚠️ <strong>Medical Disclaimer:</strong> MediAI is an AI-assisted tool for informational and educational support only. It is NOT a substitute for professional medical diagnosis, advice, or treatment. Always consult a qualified healthcare provider for clinical decisions.
        </div>

        {/* Workflow Tracker */}
        {loading && <WorkflowTracker activeNode={activeNode} />}

        <div style={{ display: "grid", gridTemplateColumns: result ? "1fr 1fr" : "1fr", gap: "24px" }}>
          {/* Left Panel — Input */}
          <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
            {/* ── Tab 0: Image Diagnosis ── */}
            {activeTab === 0 && (
              <>
                <div style={styles.card}>
                  <div style={styles.cardTitle}>🔬 Medical Image Analysis</div>
                  <ImageUploader image={image} setImage={setImage} imagePreviewUrl={imagePreviewUrl} setImagePreviewUrl={setImagePreviewUrl} />
                  <div style={{ ...styles.grid2, marginTop: "16px" }}>
                    <div>
                      <label style={styles.label}>Image Type</label>
                      <select style={styles.select} value={dataType} onChange={(e) => setDataType(e.target.value)}>
                        <option value="">Select type</option>
                        {DATA_TYPES.map((t) => <option key={t}>{t}</option>)}
                      </select>
                    </div>
                    <div>
                      <label style={styles.label}>Specialty</label>
                      <select style={styles.select} value={specialty} onChange={(e) => setSpecialty(e.target.value)}>
                        <option value="">Select</option>
                        {SPECIALTIES.map((s) => <option key={s}>{s}</option>)}
                      </select>
                    </div>
                  </div>
                </div>
                <div style={styles.card}>
                  <div style={styles.cardTitle}>📝 Additional Context</div>
                  <PatientDataForm data={patientData} setData={setPatientData} />
                  <div style={{ marginTop: "12px" }}>
                    <label style={styles.label}>Clinical Notes / Symptoms</label>
                    <textarea style={styles.textarea} placeholder="Describe symptoms, clinical observations, reason for imaging..." value={symptoms} onChange={(e) => setSymptoms(e.target.value)} />
                  </div>
                </div>
                <div style={{ display: "flex", gap: "12px" }}>
                  <button style={styles.btnPrimary} onClick={analyzeImage} disabled={loading}>
                    {loading ? <><div style={styles.spinner} /> Analyzing...</> : "🔬 Analyze Image"}
                  </button>
                  <button style={styles.btnSecondary} onClick={clearAll}>🗑️ Clear</button>
                </div>
              </>
            )}

            {/* ── Tab 1: Symptom Diagnosis ── */}
            {activeTab === 1 && (
              <>
                <div style={styles.card}>
                  <div style={styles.cardTitle}>🩺 Symptom-Based Diagnosis</div>
                  <PatientDataForm data={patientData} setData={setPatientData} />
                  <div style={{ marginTop: "12px", ...styles.grid2 }}>
                    <div>
                      <label style={styles.label}>Specialty Focus</label>
                      <select style={styles.select} value={specialty} onChange={(e) => setSpecialty(e.target.value)}>
                        <option value="">General</option>
                        {SPECIALTIES.map((s) => <option key={s}>{s}</option>)}
                      </select>
                    </div>
                    <div>
                      <label style={styles.label}>Diagnosis Type</label>
                      <select style={styles.select} value={diagnosisType} onChange={(e) => setDiagnosisType(e.target.value)}>
                        <option value="">Select</option>
                        {DIAGNOSIS_TYPES.map((d) => <option key={d}>{d}</option>)}
                      </select>
                    </div>
                  </div>
                  <div style={{ marginTop: "12px" }}>
                    <label style={styles.label}>Presenting Symptoms *</label>
                    <textarea style={{ ...styles.textarea, minHeight: "140px" }} placeholder="Describe all symptoms in detail: onset, duration, severity, location, aggravating/relieving factors, associated symptoms..." value={symptoms} onChange={(e) => setSymptoms(e.target.value)} />
                  </div>
                </div>
                <div style={{ display: "flex", gap: "12px" }}>
                  <button style={styles.btnPrimary} onClick={analyzeSymptoms} disabled={loading}>
                    {loading ? <><div style={styles.spinner} /> Analyzing...</> : "🩺 Analyze Symptoms"}
                  </button>
                  <button style={styles.btnSecondary} onClick={clearAll}>🗑️ Clear</button>
                </div>
              </>
            )}

            {/* ── Tab 2: Lab Reports ── */}
            {activeTab === 2 && (
              <>
                <div style={styles.card}>
                  <div style={styles.cardTitle}>🧪 Lab Report Interpretation</div>
                  <PatientDataForm data={patientData} setData={setPatientData} />
                  <div style={{ marginTop: "12px" }}>
                    <label style={styles.label}>Lab Values *</label>
                    <textarea style={{ ...styles.textarea, minHeight: "200px", fontFamily: "monospace", fontSize: "13px" }} placeholder={`Enter lab values, e.g.:\nHemoglobin: 10.2 g/dL\nWBC: 12,500 /µL\nPlatelets: 145,000 /µL\nFasting Glucose: 142 mg/dL\nHbA1c: 7.8%\nCreatinine: 1.4 mg/dL\nALT: 58 U/L\nTSH: 6.2 mIU/L`} value={labValues} onChange={(e) => setLabValues(e.target.value)} />
                  </div>
                </div>
                <div style={{ display: "flex", gap: "12px" }}>
                  <button style={styles.btnPrimary} onClick={analyzeLab} disabled={loading}>
                    {loading ? <><div style={styles.spinner} /> Interpreting...</> : "🧪 Interpret Report"}
                  </button>
                  <button style={styles.btnSecondary} onClick={clearAll}>🗑️ Clear</button>
                </div>
              </>
            )}

            {/* ── Tab 3: Chronic Disease ── */}
            {activeTab === 3 && (
              <>
                <div style={styles.card}>
                  <div style={styles.cardTitle}>❤️ Chronic Disease Monitoring</div>
                  <PatientDataForm data={patientData} setData={setPatientData} />
                  <div style={{ marginTop: "16px" }}>
                    <label style={styles.label}>Select Chronic Conditions</label>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
                      {CHRONIC_CONDITIONS.map((c) => (
                        <label key={c.id} style={{
                          display: "flex", alignItems: "center", gap: "8px", padding: "10px 14px",
                          borderRadius: "10px", cursor: "pointer",
                          background: chronicConditions.includes(c.id) ? "#F0FDF4" : "#F8FAFC",
                          border: `1.5px solid ${chronicConditions.includes(c.id) ? "#86EFAC" : "#E2E8F0"}`,
                          fontSize: "13px", fontWeight: 500,
                        }}>
                          <input type="checkbox" checked={chronicConditions.includes(c.id)}
                            onChange={() => setChronicConditions((prev) => prev.includes(c.id) ? prev.filter((x) => x !== c.id) : [...prev, c.id])} />
                          <span>{c.icon} {c.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  <div style={{ marginTop: "12px" }}>
                    <label style={styles.label}>Recent Values / Observations</label>
                    <textarea style={styles.textarea} placeholder="Enter recent readings: blood sugar trends, BP logs, weight changes, symptoms..." value={chronicData} onChange={(e) => setChronicData(e.target.value)} />
                  </div>
                </div>
                <div style={{ display: "flex", gap: "12px" }}>
                  <button style={styles.btnPrimary} onClick={analyzeChronic} disabled={loading}>
                    {loading ? <><div style={styles.spinner} /> Analyzing...</> : "❤️ Assess Risk"}
                  </button>
                  <button style={styles.btnSecondary} onClick={clearAll}>🗑️ Clear</button>
                </div>
              </>
            )}

            {/* ── Tab 4: Treatment Planning ── */}
            {activeTab === 4 && (
              <>
                <div style={styles.card}>
                  <div style={styles.cardTitle}>💊 Treatment Planning Support</div>
                  <PatientDataForm data={patientData} setData={setPatientData} />
                  <div style={{ marginTop: "12px" }}>
                    <label style={styles.label}>Diagnosis / Clinical Notes</label>
                    <textarea style={{ ...styles.textarea, minHeight: "160px" }} placeholder="Enter confirmed diagnosis, clinical findings, or paste results from a previous analysis..." value={treatmentNotes} onChange={(e) => setTreatmentNotes(e.target.value)} />
                  </div>
                </div>
                <div style={{ display: "flex", gap: "12px" }}>
                  <button style={styles.btnPrimary} onClick={analyzeTreatment} disabled={loading}>
                    {loading ? <><div style={styles.spinner} /> Planning...</> : "💊 Generate Plan"}
                  </button>
                  <button style={styles.btnSecondary} onClick={clearAll}>🗑️ Clear</button>
                </div>
              </>
            )}

            {/* ── Tab 5: Clinical Summary ── */}
            {activeTab === 5 && (
              <div style={styles.card}>
                <div style={styles.cardTitle}>📋 Clinical Summary Generator</div>
                <p style={{ fontSize: "13px", color: "#64748B", marginBottom: "16px" }}>
                  Run any analysis first (Image, Symptom, Lab, or Chronic Disease), then generate a structured clinical case summary.
                </p>
                {result ? (
                  <div style={{ ...styles.sectionBlock, borderLeftColor: "#6366F1" }}>
                    <div style={{ fontSize: "13px", fontWeight: 600, color: "#6366F1", marginBottom: "4px" }}>Current Findings Available</div>
                    <div style={{ fontSize: "12px", color: "#64748B" }}>{result.substring(0, 200)}...</div>
                  </div>
                ) : (
                  <div style={{ padding: "30px", textAlign: "center", color: "#94A3B8" }}>
                    No analysis results yet. Run an analysis from another tab first.
                  </div>
                )}
                <button style={{ ...styles.btnPrimary, marginTop: "16px" }} onClick={generateSummary} disabled={loading || !result}>
                  {loading ? <><div style={styles.spinner} /> Generating...</> : "📋 Generate Summary"}
                </button>
              </div>
            )}

            {/* ── Tab 6: Patient Explanation ── */}
            {activeTab === 6 && (
              <div style={styles.card}>
                <div style={styles.cardTitle}>👤 Patient-Friendly Explanation</div>
                <div style={{ marginBottom: "12px" }}>
                  <label style={styles.label}>Language</label>
                  <select style={styles.select} value={patientLanguage} onChange={(e) => setPatientLanguage(e.target.value)}>
                    {["English", "Hindi", "Spanish", "French", "German", "Mandarin", "Arabic", "Portuguese", "Kannada", "Tamil", "Telugu", "Bengali"].map((l) => (
                      <option key={l}>{l}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label style={styles.label}>Clinical Findings to Translate</label>
                  <textarea style={{ ...styles.textarea, minHeight: "160px" }} placeholder="Paste clinical findings here, or leave empty to use results from a previous analysis..." value={clinicalFindings} onChange={(e) => setClinicalFindings(e.target.value)} />
                </div>
                <button style={{ ...styles.btnPrimary, marginTop: "16px" }} onClick={generatePatientExplanation} disabled={loading}>
                  {loading ? <><div style={styles.spinner} /> Translating...</> : "👤 Explain to Patient"}
                </button>
              </div>
            )}
          </div>

          {/* Right Panel — Results */}
          {result && (
            <div style={{ display: "flex", flexDirection: "column", gap: "20px", animation: "fadeIn 0.4s ease" }}>
              {/* KPI Cards */}
              {riskScore !== null && (
                <div style={styles.card}>
                  <div style={styles.cardTitle}>📊 Assessment Overview</div>
                  <div style={{ display: "flex", gap: "20px", alignItems: "center", flexWrap: "wrap" }}>
                    <RiskScoreWidget score={riskScore} />
                    <div style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
                      <div style={styles.kpiCard("#0F766E")}>
                        <div style={{ fontSize: "11px", color: "#64748B", fontWeight: 600 }}>Status</div>
                        <div style={{ fontSize: "16px", fontWeight: 800, color: "#0F766E", marginTop: "4px" }}>
                          {riskScore >= 75 ? "Urgent" : riskScore >= 50 ? "Monitor" : "Stable"}
                        </div>
                      </div>
                      <div style={styles.kpiCard("#8B5CF6")}>
                        <div style={{ fontSize: "11px", color: "#64748B", fontWeight: 600 }}>Confidence</div>
                        <div style={{ fontSize: "16px", fontWeight: 800, color: "#8B5CF6", marginTop: "4px" }}>
                          {riskScore >= 60 ? "High" : riskScore >= 30 ? "Moderate" : "Preliminary"}
                        </div>
                      </div>
                      <div style={styles.kpiCard("#EC4899")}>
                        <div style={{ fontSize: "11px", color: "#64748B", fontWeight: 600 }}>Analysis</div>
                        <div style={{ fontSize: "16px", fontWeight: 800, color: "#EC4899", marginTop: "4px" }}>
                          {tabs[activeTab].label.split(" ").pop()}
                        </div>
                      </div>
                      <div style={styles.kpiCard("#F59E0B")}>
                        <div style={{ fontSize: "11px", color: "#64748B", fontWeight: 600 }}>Sections</div>
                        <div style={{ fontSize: "16px", fontWeight: 800, color: "#F59E0B", marginTop: "4px" }}>
                          {sections.length}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Results */}
              <div style={styles.card}>
                <div style={styles.cardTitle}>🏥 Diagnostic Report</div>
                <div style={{ maxHeight: "600px", overflowY: "auto", paddingRight: "8px" }}>
                  {sections.length > 0 ? sections.map((sec, i) => (
                    <ResultSection
                      key={i}
                      title={sec.title}
                      content={sec.content.join("\n").replace(/\*\*/g, "").trim()}
                      icon={["📋", "🔍", "🎯", "⚠️", "💡", "🔬", "📊", "🩺", "💊"][i % 9]}
                      color={sectionColors[i % sectionColors.length]}
                    />
                  )) : (
                    <div style={{ ...styles.sectionBlock, whiteSpace: "pre-wrap", fontSize: "13px", lineHeight: 1.7, color: "#334155" }}>
                      {result.replace(/\*\*/g, "").replace(/#{1,3}\s/g, "")}
                    </div>
                  )}
                </div>
              </div>

              {/* Feedback Loop */}
              <div style={styles.card}>
                <div style={styles.cardTitle}>🔁 Refinement Feedback</div>
                <textarea style={styles.textarea} placeholder="Provide clinical feedback to refine the analysis. E.g., 'Patient also has a history of...', 'Consider ruling out...', 'The X-ray shows...' " value={feedback} onChange={(e) => setFeedback(e.target.value)} />
                <div style={{ display: "flex", gap: "12px", marginTop: "12px" }}>
                  <button style={styles.btnPrimary} onClick={refineResult} disabled={loading || !feedback}>
                    🔁 Refine Analysis
                  </button>
                  <button style={styles.btnDanger} onClick={clearAll}>🗑️ Clear All</button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ textAlign: "center", padding: "32px 0 16px", color: "#94A3B8", fontSize: "12px" }}>
          <div style={{ fontWeight: 700, color: "#64748B", marginBottom: "4px" }}>MediAI Healthcare Diagnosis Intelligence Agent</div>
          <div>Built by Aigenthix • AI-Assisted Medical Decision Support • Not a substitute for professional medical advice</div>
        </div>
      </div>
    </div>
  );
}
